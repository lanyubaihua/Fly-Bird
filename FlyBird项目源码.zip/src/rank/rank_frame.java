package rank;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.List;
import javax.swing.*;

import com.csu.fly.Constant;
import com.csu.fly.MainFrame;

import database.rank_dao;
import rank.rank_information;

public class rank_frame extends JFrame {
	public MainFrame mainframe;
	public rank_frame rankframe;
	public JPanel pane;
	List<rank_information> rfs;
	public rank_frame(List<rank_information> rfs) {
		this.rfs=rfs;
	}
	public rank_frame(List<rank_information> rfs,MainFrame mainframe){//�������а����ʱ�������а����飬�Ա�ʹ�����ݣ�����ʹ�õ�����ܣ��Ա���������
		this.rfs=rfs;
		this.mainframe=mainframe;
		load();
		}
	
	//�������а����
	public void load()
	{
		rankframe=this;
		setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);		
		
		this.setLayout(null);
		this.setTitle("��ӭ����Fly-Bird");
		this.setSize(Constant.Frame_Width,Constant.Frame_Height);
		    ImageIcon backGround = new ImageIcon("images/bg_night.png");
	        JLabel bkgImage = new JLabel(backGround);
	        bkgImage.setSize(288,512);
	        bkgImage.setLocation(0,0);
	        JPanel pane = (JPanel) this.getContentPane();
	        pane.setOpaque(false);        
	      
			setContentPane(pane);
			pane.setLayout(null);		
			
			JLabel ranklabel=new JLabel("����");
			JLabel playerlabel=new JLabel("���");
			JLabel scorelabel=new JLabel("����");
			ranklabel.setBounds(45, 20, 40, 40);
			playerlabel.setBounds(135, 20, 40, 40);
			 scorelabel.setBounds(220, 20, 40, 40);
			pane.add(ranklabel);
			pane.add(playerlabel);
			pane.add(scorelabel);
			for( int i = 0 ; rfs.get(i).getName()!=null; i++) {
				JLabel label=new JLabel(Integer.toString(rfs.get(i).getRank()));
				label.setBounds(50,80*rfs.get(i).getRank()-50,50,50);
				
				JLabel label_1=new JLabel(rfs.get(i).getName());
				label_1.setBounds(135,80*rfs.get(i).getRank()-50,50,50);
				
				JLabel label_2=new JLabel(Integer.toString((rfs.get(i).getScore())));
				label_2.setBounds(220,80*rfs.get(i).getRank()-50,50,50);
				
				pane.add(label);
				pane.add(label_1);
				pane.add(label_2);
				}
			
			JButton button_yes=new JButton("ȷ��");
			button_yes.setBounds(110,400,80,30);
			button_yes.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent e){
					rankframe.dispose();
					mainframe.setVisible(true);
				}
			});
			pane.add(button_yes);
            this.getContentPane().add(bkgImage);
	        this.setResizable(false);
			this.setVisible(true);
	}
}
