package log_frame;
import log_system.user_function;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextField;
import javax.swing.border.EmptyBorder;

import database.user_dao;

import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.font.*;

//ע�����
public class frame_regist extends JFrame {

	private JPanel pane;
	private JTextField textField_name;
	private JTextField textField_password;
	public frame_regist(){
		setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
		setBounds(540, 360, 300, 300);
		pane=new JPanel();
	    pane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(pane);
		pane.setLayout(null);
		
		//�û������������
		JLabel label_name =new JLabel("�û���");
		label_name.setFont(new Font("����", Font.PLAIN, 17));
		label_name.setBounds(40, 30, 70, 30);
		pane.add(label_name);
		textField_name=new JTextField();
		textField_name.setBounds(100,30,100,30);
		pane.add(textField_name);
		
		//������������
		JLabel label_password =new JLabel("����");
		label_password.setFont(new Font("����", Font.PLAIN, 17));
		label_password.setBounds(40, 120, 70, 30);
		pane.add(label_password);
		textField_password=new JTextField();
		textField_password.setBounds(100,120,100,30);
		pane.add(textField_password);
		
		//ע�ᰴť
		JButton button_regist= new JButton("ע��");
		button_regist.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {

					user_function func=new user_function();
					if(textField_name.getText().length()==0||textField_password.getText().length()==0) {
						frame.frame_warning("�������û��������룡");
					}
					else if(func.exist(textField_name.getText())){
						frame.frame_warning("���û����ѱ�ע�ᣬ������ע�ᣡ");
					}
					else {
						func.regist(textField_name.getText(), textField_password.getText());
						frame.frame_warning("ע��ɹ���");
						
						setVisible(false);
					}
			}
		});
		button_regist.setBounds(35, 220, 90, 25);
		pane.add(button_regist);
		
		JButton button_reset = new JButton("����");
		button_reset.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				//���÷��������Ϣ
				textField_name.setText("");
				textField_password.setText("");
			}
		});
		button_reset.setBounds(165, 220, 90, 25);
		pane.add(button_reset);
	}
}
