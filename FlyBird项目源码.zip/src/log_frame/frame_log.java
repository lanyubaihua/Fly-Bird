package log_frame;

import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.List;

import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JPasswordField;
import javax.swing.JTextField;
import javax.swing.border.EmptyBorder;

import com.csu.fly.Entrance;

import database.rank_dao;
import database.user_dao;
import log_system.user_function;
import log_system.user_inf;
import rank.rank_information;
//������¼����
public class frame_log extends JFrame {
	private JPanel pane;
	private JTextField textField_name;
	private JTextField textField_password;
	frame my_frame;
	public frame_log(frame frame1) {
		this.my_frame=frame1;
		setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
	    setBounds(540, 360, 300, 300);
		ImageIcon backGround = new ImageIcon("images/weixin.png");
	    JLabel bkgImage = new JLabel(backGround);
	    bkgImage.setSize(300,300);
	    bkgImage.setLocation(0,0);
	    JPanel bkgPanel = (JPanel) this.getContentPane();
	    bkgPanel.setOpaque(false);	        
		bkgPanel.setLayout(null);
		
		//�û������������
		JLabel label_name =new JLabel("�û���");
		label_name.setFont(new Font("����", Font.PLAIN, 17));
		label_name.setBounds(40, 30, 70, 30);
		bkgPanel.add(label_name);
		textField_name=new JTextField();
		textField_name.setBounds(100,30,100,30);
		bkgPanel.add(textField_name);
		
		//������������
		JLabel label_password =new JLabel("����");
		label_password.setFont(new Font("����", Font.PLAIN, 17));
		label_password.setBounds(40, 120, 70, 30);
		bkgPanel.add(label_password);
		textField_password=new JPasswordField();
		textField_password.setBounds(100,120,100,30);
		bkgPanel.add(textField_password);
		
		JButton button_log= new JButton("��¼");
		user_function func=new user_function();
		button_log.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
					if(textField_name.getText()==""||textField_password.getText()=="") {
						frame.frame_warning("�������û��������룡");
					}
					else if(!func.exist(textField_name.getText())){
						frame.frame_warning("���û���δע�ᣬ��������ȷ���û�����");
					}
					else if(!func.log_in(textField_name.getText(), textField_password.getText())){
						frame.frame_warning("���������������ȷ�����룡");
					}
					else {
						frame.frame_warning("��¼�ɹ���");
						//���Ӵ����¼������ͬ��������������Ϸ
						user_inf user=new user_dao().query_user_inf(textField_name.getText());;
						 List<rank_information> rfs=new rank_dao().query_rank();
						my_frame.setVisible(false);
						setVisible(false);		
						
						new Entrance(user,rfs).listen();
					}
			}
		});
		button_log.setBounds(35, 220, 90, 25);
		bkgPanel.add(button_log);
		
		JButton button_reset = new JButton("����");
		button_reset.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				//���÷��������Ϣ
				textField_name.setText("");
				textField_password.setText("");
			}
		});
		button_reset.setBounds(165, 220, 90, 25);
		bkgPanel.add(button_reset);
		this.getContentPane().add(bkgImage);
	}
}
