package log_frame;
import javax.swing.*;
import javax.swing.border.EmptyBorder;

import database.rank_dao;
import rank.rank_information;

import java.awt.event.*;
import java.util.List;

//��ʼ����
public class frame extends JFrame {
	private JPanel pane;
	public static frame frame;
	public frame(){
		this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		this.setSize(240,150);
		 ImageIcon backGround = new ImageIcon("images/frame.png");
	     JLabel bkgImage = new JLabel(backGround);
	     bkgImage.setSize(240,150);
	     bkgImage.setLocation(0,0);
	     JPanel bkgPanel = (JPanel) this.getContentPane();
	     bkgPanel.setOpaque(false);
	
	     //ע�ᰴť
		JButton button_regist =new JButton("ע��");
		button_regist.setBounds(30,40, 60,30);
		bkgPanel.add(button_regist);
		
		button_regist.addActionListener(new ActionListener(){
			public void actionPerformed(ActionEvent e){
				new frame_regist().setVisible(true);
			}
		});
		
		//��¼��ť
		JButton button_log=new JButton("��¼");
		button_log.addActionListener(new ActionListener(){
			public void actionPerformed(ActionEvent e){
				new frame_log(frame).setVisible(true);
			}
		});
		button_log.setBounds(130,40, 60, 30);
		bkgPanel.add(button_log);
		this.getContentPane().add(bkgImage);
		
	}
	
	//������ʾ����String����ʾ��
	public static void frame_warning(String warning) {
		JFrame frame=new JFrame();
		JPanel pane=new JPanel();
		frame.setBounds(540, 360, 300, 150);
		frame.setContentPane(pane);
	    pane.setBorder(new EmptyBorder(5, 5, 5, 5));
		pane.setLayout(null);
		JLabel label_warning=new JLabel(warning);
		label_warning.setBounds(50,20,150,50);
		pane.add(label_warning);
		
		JButton button_yes = new JButton("ȷ��");
		button_yes.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				frame.setVisible(false);
			}
		});
		button_yes.setBounds(80, 80, 93, 23);
		pane.add(button_yes);
		
		frame.setVisible(true);
	}


	public static void main(String[] args){
		
		frame =new frame();
		frame.setLocationRelativeTo(null);
		frame.setVisible(true);
	}
	/**
	 * 
	 */
}