package music;

import java.awt.Container;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;

import com.csu.fly.Constant;
import com.csu.fly.MainFrame;



public class MusicFrame extends JFrame{
	
	//Ӧ�ð�ť�ͱ�ǩ
	JButton applyMusicButton1,applyMusicButton2;
	JLabel musicJLabel1,musicJLabel2;
	MusicPlay musicPlay1;
	MusicPlay musicPlay2;
	MainFrame mainFrame;
	MusicFrame myFrame;
    public MusicFrame(MainFrame mainFrame) {
    this.setTitle("��������");
    this.mainFrame=mainFrame;
    myFrame=this;
    }
    
    public void MusicMake()
    {
		setSize(Constant.Frame_Width ,Constant.Frame_Height);
		this.setLayout(null);
	
		//Container container=getContentPane();
		
		
		
		 ImageIcon backGround = new ImageIcon("images/bg_night.png");
	        JLabel bkgImage = new JLabel(backGround);
	        bkgImage.setSize(288,512);
	        bkgImage.setLocation(0,0);
	        JPanel bkgPanel = (JPanel) this.getContentPane();
	        bkgPanel.setOpaque(false);
	      //��ǩ�Ͱ�ť����
			//��ǩ
			JLabel musicJLabel1=new JLabel();
			JLabel musicJLabel2=new JLabel();
			
			musicJLabel1.setText("river");
			musicJLabel2.setText("Mine");
			
			musicJLabel1.setBounds(20,20,80,20);
			musicJLabel2.setBounds(20,80,80,20);
			
			bkgPanel.add(musicJLabel1);
			bkgPanel.add(musicJLabel2);
			
			//��ť
			JButton applyMusicButton1=new JButton("Ӧ��");
			JButton applyMusicButton2=new JButton("Ӧ��");
			JButton stopMusicButton1=new JButton("STOP");
			JButton stopMusicButton2=new JButton("STOP");
			JButton back=new JButton("����");
			
			back.setBounds(0, 400, 80, 50);
			applyMusicButton1.setBounds(100,20,60,20);
			applyMusicButton2.setBounds(100,80,60,20);
			stopMusicButton1.setBounds(180, 20, 80, 20);
			stopMusicButton2.setBounds(180, 80, 80, 20);
			
			bkgPanel.add(stopMusicButton1);
			bkgPanel.add(applyMusicButton1);
			bkgPanel.add(applyMusicButton2);
			bkgPanel.add(stopMusicButton2);
			bkgPanel.add(back);
	        
	        this.getContentPane().add(bkgImage);
		
		
		//���������Ӧ�¼�
	
		applyMusicButton1.addActionListener(new ActionListener() { 
			@Override
			public void actionPerformed(ActionEvent e) {
				if(musicPlay2!=null)
					musicPlay2.stop();
				musicPlay1=new MusicPlay("C:\\Users\\kuanjun\\Desktop\\river.mp3");
				JOptionPane.showMessageDialog(null, "Ӧ�óɹ���");
				musicPlay1.start();
			}
		});
		applyMusicButton2.addActionListener(new ActionListener() { 
			@Override
			public void actionPerformed(ActionEvent e) {
				if(musicPlay1!=null)
					musicPlay1.stop();
				musicPlay2=new MusicPlay("C:\\Users\\kuanjun\\Desktop\\Mine.mp3");
				JOptionPane.showMessageDialog(null, "Ӧ�óɹ���");
				musicPlay2.start();
			}
		});
		
		stopMusicButton1.addActionListener(new ActionListener()
				{
					@Override
					public void actionPerformed(ActionEvent e) {
						musicPlay1.stop();;
					}
				});
		stopMusicButton2.addActionListener(new ActionListener()
		{
			@Override
			public void actionPerformed(ActionEvent e) {
				musicPlay2.stop();
			}
		});
		back.addActionListener(new ActionListener()
				{
			public void actionPerformed(ActionEvent e) {
			
			mainFrame.setVisible(true);
			myFrame.dispose();
			
			}
			
			
				});
			
		setResizable(false);
		setVisible(true);
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
    } 
}
