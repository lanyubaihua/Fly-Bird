package music;

import java.io.BufferedInputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.net.URI;
import java.net.URL;

import javazoom.jl.decoder.JavaLayerException;
import javazoom.jl.player.Player;

public class MusicPlay extends Thread{
	File f;
	static Player  player ;
    String music;
    FileInputStream fis = null;
    public MusicPlay(String path)
    {
    	music=path;
    	
    }
    
    
    public void run() {
			
					try {
						fis = new FileInputStream(music);
					} catch (FileNotFoundException e1) {
						// TODO �Զ����ɵ� catch ��
						e1.printStackTrace();
					}
			BufferedInputStream stream = new BufferedInputStream(fis);
			try {
				player = new Player(stream);
				player.play();
			} catch (JavaLayerException e) {
				e.printStackTrace();
			}	
				
    }   
    }


