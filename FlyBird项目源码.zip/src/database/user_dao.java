package database;

import log_system.user_inf;
import java.util.*;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;


public class user_dao extends DBUtils{
	//�����û���Ϣ�����ݿ�
	public int add(user_inf u) {
		String sql="insert into user_information values(?,?,?,?,?,?,?,?)";

		Object[] params = {u.getUser_name(),u.getPassword(),u.getCoin(),u.isBird_1(),
				u.isBird_2(),u.getBird_set(),u.getMusic_set(),u.getBackground_set()};
		int i = doUpate(sql, params );
		getColse();
		return i;		
	}
	
	//�����û���Ϣ�����ݿ�
	public int update(user_inf u){
		String sql="update user_information set coin=?,bird_1=?,bird_2=?,bird_set=?,music_set=?,background_set=? where user_name=?";
		
		Object[] params = {u.getCoin(),u.isBird_1(),u.isBird_2(),u.getBird_set(),u.getMusic_set(),u.getBackground_set(),u.getUser_name()};
		System.out.print("user name"+u.getUser_name());
		int i = doUpate(sql, params);
		getColse();
		return i;
	}

	//���Ҵ����û������û���Ϣ
	public user_inf query_user_inf(String user_name) {
		String sql = "select * from user_information  where user_name=?";
		ResultSet rs = doQuery(sql, user_name);
		user_inf u=new user_inf();
		try {
			    rs.next();
				u.setPassword(rs.getString(2));
				u.setUser_name(user_name);
				System.out.print(rs.getString(2));
				u.setCoin(rs.getInt(3));
				u.setBird_1(rs.getInt(4));
				u.setBird_2(rs.getInt(5));
				u.setBird_set(rs.getInt(6));
				u.setMusic_set(rs.getInt(7));
				u.setBackground_set(rs.getInt(8));
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		getColse();
		return u;
	}
	
	//����ȫ����ע���û���
	public List<String> query_user_name(){
		String sql="select user_name from user_information ";
		ResultSet rs = doQuery(sql,null);
		List<String> names=new ArrayList<String>();
		try{
			while(rs.next()){
			String name=rs.getString(1);
			names.add(name);
			}
		}
	catch(SQLException e){
		e.printStackTrace();
		getColse();	
	}
		return names;
}
}

