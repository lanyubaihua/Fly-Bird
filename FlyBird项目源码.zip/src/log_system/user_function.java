package log_system;

import java.util.List;

import database.user_dao;
import log_system.user_inf;

public class user_function  extends user_dao {
	
	//�����Ƿ��и��û���
	public boolean exist(String user_name){
		List<String> names=query_user_name();
		if(names==null)
			return false;
		else if(names.contains(user_name))
			return true;
		else 
			return false;
	}
	//�û�ע��
   public void regist(String user_name,String password)
	{
		user_inf userInf=new user_inf(user_name,password);
		add(userInf);
		userInf=null;
	}

   //�û���¼
	public boolean log_in(String user_name,String password)
	{
		user_inf userInf=query_user_inf(user_name);
		if(password.equals(userInf.getPassword()))
			return true;
		else 
			return false;
	}
}
