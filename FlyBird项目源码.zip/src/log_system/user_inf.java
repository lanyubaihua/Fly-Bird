package log_system;

//�û���Ϣ�࣬Ŀ���Ǵ������а���Ϣ�������ݿ�����ֻ�ڿ�ʼ��ѯ���˳�ʱ����
public class user_inf {
	private String user_name;
	private String password;
	private int coin;
	private int bird_1;
	private int bird_2;
	private int bird_set;
	private int music_set;
	private int background_set;
	
	public user_inf() {
	}
	public user_inf(String name,String password){
		super();
		user_name=name;
		this.password=password;
		coin=500;//��ʼ�������
		bird_1=0;
		bird_2=0;
		bird_set=0;
		music_set=0;
		background_set=0;
	}
	public String getUser_name() {
		return user_name;
	}
	public void setUser_name(String user_name) {
		this.user_name = user_name;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	public int getCoin() {
		return coin;
	}
	public void setCoin(int coin) {
		this.coin = coin;
	}
	public int isBird_1() {
		return bird_1;
	}
	public void setBird_1(int bird_1) {
		this.bird_1 = bird_1;
	}
	public int isBird_2() {
		return bird_2;
	}
	public void setBird_2(int bird_2) {
		this.bird_2 = bird_2;
	}
	public int getBird_set() {
		return bird_set;
	}
	public void setBird_set(int bird_set) {
		this.bird_set = bird_set;
	}
	public int getMusic_set() {
		return music_set;
	}
	public void setMusic_set(int music_set) {
		this.music_set = music_set;
	}
	public int getBackground_set() {
		return background_set;
	}
	public void setBackground_set(int background_set) {
		this.background_set = background_set;
	}
}
