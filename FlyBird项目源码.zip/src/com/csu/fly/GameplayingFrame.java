package com.csu.fly;
import javax.swing.*;

import log_system.user_inf;
import rank.rank_information;

import java.awt.*;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.awt.image.BufferedImage;
import java.util.List;

import static java.lang.Thread.sleep;
 public class GameplayingFrame extends JFrame{

	private static final long serialVersionUID = 1L;
	user_inf user;
	MainFrame mainframe;
	List<rank_information> rfs;
	Graphics g=this.getGraphics();
	GameplayingFrame(user_inf user,List<rank_information> rfs,MainFrame mainframe)
	{
		this.mainframe=mainframe;
		this.rfs=rfs;
		this.user=user;
		this.setTitle("Fly Bird");
        this.setSize(Constant.Frame_Width,Constant.Frame_Height);
        this.setResizable(false);
        this.setLocationRelativeTo(null);
        this.setVisible(true);
        Scene stage = new Scene(user);
        Graphics g = this.getGraphics(); 
        ImageIcon backGround = new ImageIcon("images/bg_day.png");
        JLabel bkgImage = new JLabel(backGround);
        bkgImage.setSize(288,512);
        bkgImage.setLocation(0,0);
        JPanel bkgPanel = (JPanel) this.getContentPane();
        bkgPanel.setOpaque(false);
        this.getContentPane().add(bkgImage);
        //Ϊ�������������Ӧ�¼�
        this.addMouseListener(new MouseListener(){
			@Override
			public void mouseReleased(MouseEvent e) {}
			@Override
			public void mousePressed(MouseEvent e) {	
			}
			@Override
			public void mouseExited(MouseEvent e) {	
			}
			
			@Override
			public void mouseEntered(MouseEvent e) {	
			}
			@Override
			public void mouseClicked(MouseEvent e) {
			    stage.speed_y=-175;
			}
		});
        JLabel scoreText = new JLabel();
        Font font = new Font(Font.SERIF, Font.ITALIC, 30);
        scoreText.setFont(font);
        scoreText.setText(String.valueOf(0));
        this.setLayout(null);
        scoreText.setBounds(129,0,30,30);
        this.add(scoreText);
        //����һ���̶߳��������ظ���ͼ������Լ���̵߳���Դ��ʹ��Ϸ���и�������
        new Thread(new playingThread(stage,g,this,user,rfs,mainframe)).start(); 
    }		

	}
	
 /*
  * �����࣬��������Ϸ�������Ʒ�Լ���Ϸʵ�ֵ��㷨
  */
class  Scene{
    //��׺_x/_y��ʾ��/�����꣬�������Ͻ�Ϊԭ��
    public final int bird_x = 88;
    //�������ٶ�
    public final int G = 300;
    public double bird_y;
    public double birdRadius;
    //�ٶȡ�����ֵΪ���£���ֵΪ����
    public int speed_x;
    public int speed_y;
    private  Ground land= new Ground(GameUtil.toBufferedImage(GameUtil.getImage("ioo/land.png")));
    BufferedImage back=  GameUtil.toBufferedImage(GameUtil.getImage("ioo/bg_day.png")) ;   
    Barrier barrier;
    Barrier barrier1;
    Ground ground;
    FlyingBird bird=null;
    Scene(user_inf user){
    	bird_y = 200;
        bird=new FlyingBird(bird_x,bird_y,user);
        birdRadius = 22;
        speed_x = 3;
        speed_y = 0;
        ground = new Ground(GameUtil.toBufferedImage(GameUtil.getImage("ioo/land.png")));
        barrier= new Barrier(GameUtil.toBufferedImage(GameUtil.getImage("ioo/pipe_down1.png")));
        barrier1= new Barrier(GameUtil.toBufferedImage(GameUtil.getImage("ioo/pipe_down.png")));      
    } 
    
    //����true����Ϸ�Ѿ�����������false��ʾ��Ϸ��������
    	 boolean ifGameOver(){
    	        //��������
    	        if(bird_y + birdRadius > 512 - ground.getHeight()){
    	            System.out.println("hit ground");
    	            return true;
    	        }
    	        //������
    	        if(bird_y - birdRadius < 0){
    	            System.out.println("hit sky");
    	            return true;
    	        }
    	        //δ����߽�ʱ
    	        if(bird_x + birdRadius <= barrier.location_x){
    	            return false;
    	        }
    	        //�ӽ���߽�ʱ
    	        if(bird_x + birdRadius > barrier.location_x && bird_x < barrier.location_x){
    	            if(bird_y < barrier.topHeight || bird_y + birdRadius*0.7 > 512 - barrier.bottomHeight){
    	                System.out.println("hit left edge");
    	                return true;
    	            }
    	            return false;
    	        }
    	        //ͨ���ܵ�ʱ
    	        if(bird_x >= barrier.location_x && bird_x < barrier.location_x + barrier.width){

    	            boolean y1 = bird_y + birdRadius > 512 - barrier.bottomHeight;
    	            boolean y2 = bird_y  <barrier.topHeight;
    	            if(y1 || y2){
    	                System.out.println("hit inside");
    	            }
    	            return y1 || y2;
    	        }
    	        //��ͨ���ܵ�
    	        if(bird_x >= barrier.location_x + barrier.width){
    	            return false;
    	        }
    	        return false;
    	    }
    //ifGameOver=falseʱ��ִ��
    boolean ifGetScore(){
        return bird_x + birdRadius > barrier.location_x;
    }
    //�ڶ���֮��Ļ�ͼ
    public void drawItems(Graphics g){
        //�� 
        bird.draw(g);
    	//���ϰ���
    	g.drawImage(barrier.img, barrier.location_x, 512 - barrier.bottomHeight,33,barrier.bottomHeight, null);
        //���ϰ���
    	g.drawImage(barrier1.img,barrier.location_x, 0,33,barrier.topHeight, null);
    
        //����
        g.drawImage(ground.getBufferedImage(),0,512-30, null);
        ground.checkGround();
        barrier.checkBarrier();
    }
    //���¸��������λ�ã�ÿ��30�Σ�
    public void itemMove() {
        //��������ٶ�
        speed_y += G*0.033;

        //�����������ٶ�Ϊ220
        if(speed_y > 220){
            speed_y = 220;
        }

        //�������������
        bird_y += speed_y*0.033;
          bird.y=bird_y;
        //�����ϰ���͵���ĺ�����
        barrier.location_x -= speed_x;
        ground.setX(ground.getX()-speed_x);
    }
    
  //���ٷ���,���ݷ��������ٶ�
    public void shift(int score){
        if(score < 1) {
            speed_x = 3;
        }
        else if (score < 100){
            speed_x = 4;
        }
        else if (score < 200){
            speed_x = 5;
        }
        else if (score < 300){
            speed_x = 6;
        }
        else if (score < 400){
            speed_x = 7;
        }
        else if (score < 500){
            speed_x = 8;
        }
        else speed_x = 9;
    }
    
    
    
}



