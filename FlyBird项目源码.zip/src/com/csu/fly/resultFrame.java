package com.csu.fly;

import javax.swing.*;

import log_system.user_inf;
import rank.rank_frame;
import rank.rank_information;

import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.List;

//�����ʾ����
public class resultFrame extends JFrame{
	 /**
	 * ��Ϸ������
	 */
	private static final long serialVersionUID = 2022492806553865597L;
	JButton againbutton;
	 JButton backbutton;
	 JButton goingRankbutton;
	 JLabel scorelabel;
	 MainFrame mainframe;
	 List<rank_information> rfs;
	 resultFrame myresultFrame;
	    user_inf user;
    resultFrame(int score, user_inf user,List<rank_information> rfs,MainFrame mainframe){
    	this.mainframe=mainframe;
    	this.user=user;
    	myresultFrame=this;
    	this.rfs=rfs;
        this.setLayout(null);
		this.setTitle("��ӭ����Fly-Bird");
		this.setSize(200,334);
		this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		    ImageIcon backGround = new ImageIcon("images/gameover1.png");
	        JLabel bkgImage = new JLabel(backGround);
	        bkgImage.setSize(200,334);
	        bkgImage.setLocation(0,0);
	        JPanel bkgPanel = (JPanel) this.getContentPane();
	        bkgPanel.setOpaque(false);
	        scorelabel=new JLabel(String.valueOf(score));
	        scorelabel.setBounds(100,150,40,40);
	        this.getContentPane().add(scorelabel);
	        againbutton=new JButton();
	        againbutton.setBounds(70, 190, 70, 30);
	        againbutton.setContentAreaFilled(false);//��ť��Ϊ���ɼ�
	        //���ӡ�����һ�Ρ���ť����Ӧ����
	        againbutton.addActionListener(new ActionListener()
	        		{
						@Override
						public void actionPerformed(ActionEvent e) {
							myresultFrame.dispose();
						new GameplayingFrame(user,rfs,mainframe);	
						}
	        		});
	        	
	        this.getContentPane().add(againbutton);
	        goingRankbutton=new JButton();
	        goingRankbutton.setBounds(70, 235, 70, 30);
	        goingRankbutton.setContentAreaFilled(false);//��ť��Ϊ���ɼ�
	        //���ӡ��鿴���а񡱰�ť����Ӧ����
	        goingRankbutton.addActionListener(new ActionListener()
    		{
				@Override
				public void actionPerformed(ActionEvent e) {
					myresultFrame.dispose();
				      new rank_frame(rfs).setVisible(true);	
				}
    		});
	        this.getContentPane().add(goingRankbutton);
	        backbutton=new JButton("����");
	        backbutton.setBounds(0, 0, 25, 21);
	        ImageIcon icon=new ImageIcon("images/hh.png");
	        backbutton.setIcon(icon);
	        this.getContentPane().add(backbutton);
	        //���ӡ����������桱��ť����Ӧ����
	        backbutton.addActionListener(new ActionListener()
	        		{

						@Override
						public void actionPerformed(ActionEvent e) {
							myresultFrame.dispose();
							mainframe.setVisible(true);
							
						}
	        	
	        		});     	
	       
	        this.getContentPane().add(bkgImage);
	        this.setResizable(false);
			this.setVisible(true);
  
}
    
}   
    
