package com.csu.fly;

import java.awt.image.BufferedImage;
public class Barrier {
	    public int width=33;//�ϰ������
	    public int location_x = 288 - width;//��߽�λ��
	    public int topHeight;//��
	    public int bottomHeight;//��
	    public int distance_y =150;//�ݼ��
	    public  BufferedImage img=null;
	    Barrier(BufferedImage img){
	    	this.img=img;
	        int val = (int) (Math.random() * 100) +100;
	        topHeight = val;
	        bottomHeight = 512 - val - distance_y;
	    }
	    //����ϰ����Ƿ����
	    public void checkBarrier(){
	        if(location_x < 0){
	            location_x = 288 - width;
	            int val = (int) (Math.random() * 150) +100;
	            topHeight = val;
	            bottomHeight = 512 - val - distance_y;
	            playingThread.flag = true;
	        }
	    }
	
}
