package com.csu.fly;

import java.awt.Color;
import java.awt.Container;
import java.awt.Font;
import java.awt.Graphics;
import java.awt.Image;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import java.awt.image.BufferedImage;
import java.util.Date;
import java.util.List;

import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextField;

import database.rank_dao;
import log_system.user_inf;
import rank.rank_frame;
import rank.rank_information;


public class MainFrame extends JFrame{
	/**
	 * ��������
	 */
	user_inf user;
	private static final long serialVersionUID = 3593770226095100695L;
	public  JButton beginButton;
	public JButton rankButton;
	public JButton setButton;
	public JButton exitButton;
	public JButton storeButton;
	MainFrame()
	{
	}
	/*
	 * ҳ��ļ��ط���������������ӵ�������
	 * 
	 */
	public void LaunchFrame() {
		this.setLayout(null);
		this.setTitle("��ӭ����Fly-Bird");
		this.setSize(Constant.Frame_Width,Constant.Frame_Height);
		this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		    ImageIcon backGround = new ImageIcon("images/bg.png");
	        JLabel bkgImage = new JLabel(backGround);
	        bkgImage.setSize(288,512);
	        bkgImage.setLocation(0,0);
	        JPanel bkgPanel = (JPanel) this.getContentPane();
	        bkgPanel.setOpaque(false);
	        //������Ϸ��ť
	        beginButton=new JButton();
	        beginButton.setBounds(100, 382, 90, 50);
	        beginButton.setContentAreaFilled(false);
	        this.getContentPane().add(beginButton);
	      //���а�ť
	        rankButton=new JButton(new ImageIcon("images/rank.jpg"));
	        rankButton.setBounds(0, 450, 100, 21);
	        this.getContentPane().add(rankButton);
	        
	      //���ð�ť
	        setButton=new JButton();
	        setButton.setBounds(0, 52, 38, 38);
	        setButton.setContentAreaFilled(false);
	        this.getContentPane().add(setButton);
	        
	      //�̳ǰ�ť
		   storeButton=new JButton(new ImageIcon("images/store.jpg"));
		   storeButton.setBounds(188, 450, 100, 21);
		   this.getContentPane().add(storeButton);
	       
	        
	        this.getContentPane().add(bkgImage);
	        this.setResizable(false);
			this.setVisible(true);

	}

	

}


