package com.csu.fly;

import java.awt.Container;
import java.awt.Graphics;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.image.BufferedImage;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JMenu;
import javax.swing.JMenuBar;
import javax.swing.JOptionPane;
import javax.swing.JPanel;

import database.user_dao;
import log_system.user_inf;
public class StoreFrame extends JFrame {
	/**
	 * 
	 */
	private static final long serialVersionUID = 4356114328663435315L;
	// �˵���
	user_inf user;
	JMenuBar menuBar;
	JMenu skinmenu;
	JLabel bird1_label, bird2_label, gold_label;
	JButton Bird1_buy_button, Bird2_buy_button;
	JButton Bird1_apply_button, Bird2_apply_button;
	JButton Bird1_ensure_button, Bird2_ensure_button;
	JButton backMainFrame;
	int bird1_flag = 0, bird2_flag = 0;
	// Ƥ��ͼƬ
	
	BufferedImage birdImage1 = GameUtil.toBufferedImage(GameUtil.getImage("ioo/bird1_01.png"));
	BufferedImage birdImage2 = GameUtil.toBufferedImage(GameUtil.getImage("ioo/bird2_02.png"));
	BufferedImage bg = GameUtil.toBufferedImage(GameUtil.getImage("ioo/store_bg.png"));

	// ���췽��
	public StoreFrame(String name,user_inf user) {
		this.user=user;
		this.setTitle(name);
		setSize(Constant.Frame_Width, Constant.Frame_Height);
		this.setLayout(null);
	}

	// �̳�������
	public void FrameMake(MainFrame mainframe,StoreFrame store) {
		// ���ò˵���
		menuBar = new JMenuBar();
		skinmenu = new JMenu("Ƥ��");
		menuBar.add(skinmenu);
		setJMenuBar(menuBar);
		Container container = getContentPane();
		// ���ô�����ɫ
        backMainFrame=new JButton("����������");
        backMainFrame.setBounds(0, 380, 100, 20);
        
        backMainFrame.addActionListener(new ActionListener()
		 {
			@Override
			public void actionPerformed(ActionEvent e) {
				store.dispose();
				new user_dao().update(user);
				mainframe.setVisible(true);
				
			
			}});
        
        
        container.add(backMainFrame);
		
        
		// ���ü۸��ǩ
		bird1_label = new JLabel("44");
		bird1_label.setBounds(45, 70, 20, 10);
		container.add(bird1_label);

		bird2_label = new JLabel("500");
		bird2_label.setBounds(170, 70, 20, 10);
		container.add(bird2_label);

		// ���ý��
		gold_label = new JLabel("�������" + user.getCoin());
		gold_label.setBounds(180, 380, 100, 20);
		container.add(gold_label);

		// ����Ӧ��Ƥ����ť
		Bird1_apply_button = new JButton("Ӧ��Ƥ��");
		Bird2_apply_button = new JButton("Ӧ��Ƥ��");
		// ���ù���ť
		Bird1_buy_button = new JButton("����");
		Bird2_buy_button = new JButton("����");
		Bird2_apply_button.setBounds(140, 90, 100, 20);
		Bird1_buy_button.setBounds(15, 90, 100, 20);
		Bird2_buy_button.setBounds(140, 90, 100, 20);
		Bird1_apply_button.setBounds(15, 90, 100, 20);
		if(user.isBird_1()==0)
			container.add(Bird1_buy_button);
			else
				container.add(Bird1_apply_button);
			
		if(user.isBird_2()==0)
			container.add(Bird2_buy_button);
			else
				container.add(Bird2_apply_button);
	

		// ����ȷ����ť
		Bird1_ensure_button = new JButton("ȷ��");
		Bird2_ensure_button = new JButton("ȷ��");

		JPanel j = new JPanel();
		j.setLayout(null);
		// ���������Ӵ���
		JFrame Bird1_frame = new JFrame();
		JFrame Bird2_frame = new JFrame();
		
		Bird1_buy_button.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				int remaining_gold_number =user.getCoin();
				Bird1_frame.setSize(Constant.SHOP_WINDOWS_WIDTH, Constant.SHOP_WINDOWS_HEIGHT);
				if (remaining_gold_number >= Constant.BIRD_PRICE1) {
					JLabel label = new JLabel("����ɹ�", JLabel.CENTER);
					remaining_gold_number -= Constant.BIRD_PRICE1;
					user.setCoin(remaining_gold_number);
					 user.setBird_1(1);
					// ���Ľ����,�ɹ�
					container.remove(gold_label);
					gold_label.setText("�������" + remaining_gold_number);
					container.add(gold_label);
					gold_label.setBounds(180, 380, 100, 20);
					gold_label.repaint();
					//

					Bird1_frame.add(Bird1_ensure_button);
					Bird1_ensure_button.setBounds(25, 70, 80, 20);

					Bird1_frame.add(label);
					Bird1_frame.setVisible(true);

				} else {
					JLabel label = new JLabel("����ʧ��", JLabel.CENTER);
					Bird1_ensure_button.setBounds(25, 70, 80, 20);
					Bird1_frame.add(Bird1_ensure_button);
					Bird1_frame.add(label);
					Bird1_frame.setVisible(true);
				}
				if(user.isBird_1()==0)
					container.add(Bird1_buy_button);
					else
						container.remove(Bird1_buy_button);
				        container.add(Bird1_apply_button);
				        Bird1_buy_button.repaint();
			}

		});

		Bird2_buy_button.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
		
				int remaining_gold_number =user.getCoin();
				Bird2_frame.setSize(Constant.SHOP_WINDOWS_WIDTH, Constant.SHOP_WINDOWS_HEIGHT);
				if (remaining_gold_number>= Constant.BIRD_PRICE2) {
					JLabel label = new JLabel("����ɹ�", JLabel.CENTER);
					
					remaining_gold_number-= Constant.BIRD_PRICE2;
				   user.setCoin(remaining_gold_number);
		             user.setBird_2(1);
					// ���ý����
					container.remove(gold_label);
					gold_label.setText("�������" + remaining_gold_number);
					container.add(gold_label);
					gold_label.setBounds(180, 380, 100, 20);
					gold_label.repaint();
					
					Bird2_ensure_button.setBounds(20, 70, 80, 20);
					Bird2_frame.add(Bird2_ensure_button);
					
					Bird2_frame.add(label);
					Bird2_frame.setVisible(true);
				} else {
					JLabel label = new JLabel("����ʧ��", JLabel.CENTER);
					Bird2_ensure_button.setBounds(20, 70, 80, 20);
					Bird2_frame.add(Bird2_ensure_button);
					Bird2_frame.add(label);
					Bird2_frame.setVisible(true);
				}
				if(user.isBird_2()==0)
					container.add(Bird2_buy_button);
					else
					{  
						container.remove(Bird2_buy_button);
						container.add(Bird2_apply_button);
						Bird2_buy_button.repaint();
					}
			}
		});
	
		Bird1_ensure_button.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				
					//Bird1_apply_button.repaint();
				      Bird1_frame.dispose();
			}
		});

		Bird2_ensure_button.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				
					Bird2_apply_button.repaint();
				    Bird2_frame.dispose();
			}
		});

		// Ӧ��Ƥ��
		Bird1_apply_button.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				
				user.setBird_set(1);
				JOptionPane.showMessageDialog(null, "Ӧ�óɹ���");
			}
		});
		Bird2_apply_button.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				user.setBird_set(2);
				JOptionPane.showMessageDialog(null, "Ӧ�óɹ���");
			}
		});
		// �رմ��ںʹ��ڿ��ӻ�
		setResizable(false);
		setVisible(true);
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

	}

	// ��Ʒ����
	public void paint(Graphics g) {
		super.paint(g);
		g.drawImage(birdImage1, 20, 50, null);
		g.drawImage(birdImage2, 144, 50, null);
		Bird1_buy_button.requestFocus();
		Bird1_buy_button.requestFocus();
		gold_label.requestFocus();
		setVisible(true);
	}
	
	


}
