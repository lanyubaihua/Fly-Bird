package com.csu.fly;

import java.awt.event.ActionEvent;

import java.awt.event.ActionListener;
import java.util.List;
import javax.swing.JButton;
import database.rank_dao;
import log_system.user_inf;
import music.MusicFrame;
import rank.rank_frame;
import rank.rank_information;
public class Entrance {
	user_inf user;
	 StoreFrame store;
	 List<rank_information> rfs;
	 /*
	  * Entrance���ǵ�¼�ɹ�����������а�ť����Ӧ������ͨ���˶�����벻ͬ�Ľ��档
	  */
	 public Entrance(user_inf user,List<rank_information> rfs)
	 {
		 this.rfs=rfs;
		 this.user=user;
	 }
	public   void  listen() {
		MainFrame mainFrame= new MainFrame();
		mainFrame.LaunchFrame();
		/*
		 * ��ʼ������
		 */
		mainFrame.beginButton.addActionListener(new ActionListener()
		{
	       public void actionPerformed(ActionEvent e) {
		   mainFrame.setVisible(false);
		   new GameplayingFrame(user, rfs,mainFrame);
	}
		}
		);
		/*
		 * ���а������
		 */
		mainFrame.rankButton.addActionListener(new ActionListener()
				{
			public void actionPerformed(ActionEvent e) {
				  mainFrame.setVisible(false);
				rank_frame frame =new rank_frame(rfs,mainFrame);
				frame.setLocationRelativeTo(null);
				frame.setVisible(true);
				
				 
			}
				}
				);

		/*
		 * ���ð�ť������
		 */
		mainFrame.setButton.addActionListener(new ActionListener()
				{
			public void actionPerformed(ActionEvent e) {
				mainFrame.setVisible(false);
				new MusicFrame(mainFrame).MusicMake();
				 
			}
				}
				);
	
		/*
		 * �̵������
		 */
		mainFrame.storeButton.addActionListener(new ActionListener()
		{
	    public void actionPerformed(ActionEvent e) {	
	      mainFrame.setVisible(false);
		  store= new StoreFrame("�̳�",user); 
		  store.FrameMake(mainFrame,store);
				 }});
}
	
}
