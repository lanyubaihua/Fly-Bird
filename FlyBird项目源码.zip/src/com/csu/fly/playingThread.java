package com.csu.fly;

import static java.lang.Thread.sleep;

import java.awt.Graphics;
import java.awt.Image;
import java.util.List;

import javax.swing.ImageIcon;
import javax.swing.JLabel;
import javax.swing.JPanel;

import database.rank_dao;
import database.user_dao;
import log_system.user_inf;
import rank.rank_information;

/*
 *�߳��������ظ���ͼ
 * 
 */
public class playingThread implements Runnable {
	Scene stage;
	private Image iBuffer;
    private Graphics gBuffer;
    List<rank_information> rfs;
    user_inf user;
    MainFrame mainframe;
	Graphics g ;
	GameplayingFrame playingframe ;
	public static boolean flag = true;//���ƼƷְ�ı���
	public int score = 0;//����
	playingThread(Scene stage,Graphics g,GameplayingFrame playingframe ,user_inf user,List<rank_information> rfs,MainFrame mainframe)
	{
		this.mainframe=mainframe;
		this.rfs=rfs;
		this.user=user;
		this.stage=stage;
		this.g=g;
		this.playingframe=playingframe;
		
	}
	@Override
	public void run() {
		 while (!stage.ifGameOver()){
	             stage.drawItems(g);//�滭
	             stage.itemMove();//�����ƶ�
	            //33msˢ��һ��
	            try {
	                sleep(33);
	            } catch (InterruptedException e) {
	                e.printStackTrace();
	            }
	            if(stage.ifGetScore()){
	                    score++;
	            }
	            stage.shift(score);
	            //playingframe.update(g);
	            //�����һ�λ滭���
	          //˫���巽�������һ�λ滭���
	            if (iBuffer == null){
	                iBuffer = playingframe.createImage(playingframe.getSize().width,playingframe.getSize().height);
	                gBuffer = iBuffer.getGraphics();
	            }
	            playingframe.paint(gBuffer);
	            g.drawImage(iBuffer,0,0,null);
	          //  stage.drawItems(g);//�ٻ滭
	        }
		     user.setCoin(user.getCoin()+score);
		     new user_dao().update(user);
		     playingframe.setVisible(false);
		     rank_information rf=new rank_information();
		     rf.setScore(score);
		     rf.setName(user.getUser_name());
		     rfs.add(rf);
		      new rank_dao().update_rank(rfs);
		      new  resultFrame(score,user,rfs,mainframe);
		      System.out.println("game over");
	  
	        
		
		
		
	}

}
